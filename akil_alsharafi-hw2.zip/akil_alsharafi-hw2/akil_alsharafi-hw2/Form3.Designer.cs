﻿namespace akil_alsharafi_hw2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.colorpanal = new System.Windows.Forms.Panel();
            this.red_btn = new System.Windows.Forms.Button();
            this.green_btn = new System.Windows.Forms.Button();
            this.yellow = new System.Windows.Forms.Button();
            this.backbtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // colorpanal
            // 
            this.colorpanal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.colorpanal.Location = new System.Drawing.Point(68, 208);
            this.colorpanal.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.colorpanal.Name = "colorpanal";
            this.colorpanal.Size = new System.Drawing.Size(607, 184);
            this.colorpanal.TabIndex = 0;
            // 
            // red_btn
            // 
            this.red_btn.Location = new System.Drawing.Point(77, 74);
            this.red_btn.Name = "red_btn";
            this.red_btn.Size = new System.Drawing.Size(119, 49);
            this.red_btn.TabIndex = 1;
            this.red_btn.Text = "RED";
            this.red_btn.UseVisualStyleBackColor = true;
            this.red_btn.Click += new System.EventHandler(this.main_event_Click);
            // 
            // green_btn
            // 
            this.green_btn.Location = new System.Drawing.Point(312, 74);
            this.green_btn.Name = "green_btn";
            this.green_btn.Size = new System.Drawing.Size(119, 49);
            this.green_btn.TabIndex = 2;
            this.green_btn.Text = "GREEN";
            this.green_btn.UseVisualStyleBackColor = true;
            this.green_btn.Click += new System.EventHandler(this.main_event_Click);
            // 
            // yellow
            // 
            this.yellow.Location = new System.Drawing.Point(556, 74);
            this.yellow.Name = "yellow";
            this.yellow.Size = new System.Drawing.Size(119, 49);
            this.yellow.TabIndex = 3;
            this.yellow.Text = "YELLOW";
            this.yellow.UseVisualStyleBackColor = true;
            this.yellow.Click += new System.EventHandler(this.main_event_Click);
            // 
            // backbtn
            // 
            this.backbtn.Location = new System.Drawing.Point(275, 413);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(166, 49);
            this.backbtn.TabIndex = 4;
            this.backbtn.Text = "Back";
            this.backbtn.UseVisualStyleBackColor = true;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(256, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(198, 34);
            this.label7.TabIndex = 7;
            this.label7.Text = "Second Form";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(53, 438);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 24);
            this.label2.TabIndex = 8;
            this.label2.Text = "Akil Al-sharafi";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 485);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.yellow);
            this.Controls.Add(this.green_btn);
            this.Controls.Add(this.red_btn);
            this.Controls.Add(this.colorpanal);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.Name = "Form2";
            this.Text = "Akil Al-sharafi";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel colorpanal;
        private System.Windows.Forms.Button red_btn;
        private System.Windows.Forms.Button green_btn;
        private System.Windows.Forms.Button yellow;
        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
    }
}