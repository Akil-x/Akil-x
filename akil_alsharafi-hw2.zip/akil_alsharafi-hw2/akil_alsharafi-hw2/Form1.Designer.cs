﻿namespace akil_alsharafi_hw2
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.p1btn = new System.Windows.Forms.Button();
            this.p2btn = new System.Windows.Forms.Button();
            this.p3btn = new System.Windows.Forms.Button();
            this.p4btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(108, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Choose The Programm ";
            // 
            // p1btn
            // 
            this.p1btn.Location = new System.Drawing.Point(169, 145);
            this.p1btn.Name = "p1btn";
            this.p1btn.Size = new System.Drawing.Size(116, 41);
            this.p1btn.TabIndex = 1;
            this.p1btn.Text = "1";
            this.p1btn.UseVisualStyleBackColor = true;
            this.p1btn.Click += new System.EventHandler(this.p1btn_Click);
            // 
            // p2btn
            // 
            this.p2btn.Location = new System.Drawing.Point(169, 214);
            this.p2btn.Name = "p2btn";
            this.p2btn.Size = new System.Drawing.Size(116, 41);
            this.p2btn.TabIndex = 2;
            this.p2btn.Text = "2";
            this.p2btn.UseVisualStyleBackColor = true;
            this.p2btn.Click += new System.EventHandler(this.p2btn_Click);
            // 
            // p3btn
            // 
            this.p3btn.Location = new System.Drawing.Point(169, 286);
            this.p3btn.Name = "p3btn";
            this.p3btn.Size = new System.Drawing.Size(116, 41);
            this.p3btn.TabIndex = 3;
            this.p3btn.Text = "3";
            this.p3btn.UseVisualStyleBackColor = true;
            this.p3btn.Click += new System.EventHandler(this.p3btn_Click);
            // 
            // p4btn
            // 
            this.p4btn.Location = new System.Drawing.Point(169, 357);
            this.p4btn.Name = "p4btn";
            this.p4btn.Size = new System.Drawing.Size(116, 41);
            this.p4btn.TabIndex = 4;
            this.p4btn.Text = "4";
            this.p4btn.UseVisualStyleBackColor = true;
            this.p4btn.Click += new System.EventHandler(this.p4btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(159, 429);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "Akil Al-sharafi";
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 468);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.p4btn);
            this.Controls.Add(this.p3btn);
            this.Controls.Add(this.p2btn);
            this.Controls.Add(this.p1btn);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.Name = "Home";
            this.Text = "Akil-Alsharafi-HW2";
            this.Load += new System.EventHandler(this.vcm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button p1btn;
        private System.Windows.Forms.Button p2btn;
        private System.Windows.Forms.Button p3btn;
        private System.Windows.Forms.Button p4btn;
        private System.Windows.Forms.Label label2;
    }
}

