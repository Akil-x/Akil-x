﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace akil_alsharafi_hw2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            red_btn.Tag = Color.Red;
            green_btn.Tag = Color.Green; 
            yellow.Tag = Color.Yellow;
        }

        private void main_event_Click(object sender, EventArgs e)
        {
            colorpanal.BackColor = (Color)(((Button)sender).Tag);
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Home f = new Home();
            f.Show();
            this.Close();
        }
    }
}
