﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace akil_alsharafi_hw2
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        private void numbox_event_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == '\b'))
            {
                e.Handled = true;
            }
        }
        private bool check_input()
        {
            if(fnumbox.Text == "")
            {
                MessageBox.Show("You Must Enter Number");
                fnumbox.Focus();
                return false;
            }
            return true;
        }
        private double sum(double n)
        {
            double r = 0;
            for(int i=1; i<= n; i++)
            {
                r += i;
            }
            return r;
        }
        private double fact(double n)
        {
            double r = 1;
            for (int i = 2; i <= n; i++)
            {
                r *= i;
            }
            return r;
        }

        private double root(double n)
        {
            return Math.Pow(n, 1.0/2);
        }

        private void sumbtn_Click(object sender, EventArgs e)
        {
            if (check_input())
            {
                Form5.Text = sum(Convert.ToDouble(fnumbox.Text)).ToString();
            }
        }

        private void factbtn_Click(object sender, EventArgs e)
        {
            if (check_input())
            {
                fact_label.Text = fact(Convert.ToDouble(fnumbox.Text)).ToString();
            }
        }

        private void rootbtn_Click(object sender, EventArgs e)
        {
            if (check_input())
            {
                root_label.Text = root(Convert.ToDouble(fnumbox.Text)).ToString();
            }
        }
    }
}
