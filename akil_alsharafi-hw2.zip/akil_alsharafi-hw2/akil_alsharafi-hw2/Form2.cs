﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace akil_alsharafi_hw2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void fForm_Load(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private bool  check_input()
        {
            if (fnumbox.Text == "")
            {
                MessageBox.Show("You Must Add The First Number");
                fnumbox.Focus();
            }else if (snumbox.Text == "")
            {
                MessageBox.Show("You Must Add The Secand Number");
                snumbox.Focus();
            }
            else if (tnumbox.Text == "")
            {
                MessageBox.Show("You Must Add The Third Number");
                tnumbox.Focus();
            }
            else if (op1box.Text == "")
            {
                MessageBox.Show("You Must Add The First Opertion");
                op1box.Focus();
            }
            else if (op2box.Text == "")
            {
                MessageBox.Show("You Must Add The Secand Opertion");
                op2box.Focus();
            }
            else
            {
                return true;
            }

            return false;
        }

        private void numbox_event_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == '\b'))
            {
                e.Handled = true;
            }
        }
        private void op_event_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(e.KeyChar == '+' || e.KeyChar == '-' || e.KeyChar == '/' || e.KeyChar == '*' ) || ((TextBox)sender).Text.Length == 1)
            {
                e.Handled = true;
            }
            if(e.KeyChar == '\b')
            {
                e.Handled = false;
            }
        }

        private void get_priority(ref double f , ref double s , ref double t, ref string op1, ref string op2)
        {
            if (op1box.Text == "*" || op1box.Text == "/")
            {
         
            }
            else if  (op2box.Text == "*" || op2box.Text == "/")
            {
                double temp = f;
                string tempop = op1;
                op1 = op2;
                op2 = tempop;
                f = s;
                s = t;
                t = temp;
            }
        }
        private double calculate(double num1, double num2, double num3, string op1, string op2)
        {
            double result;
            if (op1 == "*")
            {
                result = num1 * num2;
            }
            else if (op1 == "/")
            {
                if (num2 == 0)
                {
                    MessageBox.Show("Cannot divide by zero!");
                    return double.NaN;
                }
                result = num1 / num2;
            }
            else if (op1 == "+")
            {
                result = num1 + num2;
            }
            else
            {
                result = num1 - num2;
            }

            if (op2 == "*")
            {
                result *= num3;
            }
            else if (op2 == "/")
            {
                if (num3 == 0)
                {
                    MessageBox.Show("Cannot divide by zero!");
                    return double.NaN;
                }
                result /= num3;
            }
            else if (op2 == "+")
            {
                result += num3;
            }
            else
            {
                result -= num3;
            }

            return result;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (check_input())
            {
                double fnum = Convert.ToDouble(fnumbox.Text), 
                    snum = Convert.ToDouble(snumbox.Text),
                    tnum = Convert.ToDouble(tnumbox.Text);
                string op1 = op1box.Text,
                    op2 = op2box.Text;
                get_priority(ref fnum, ref snum, ref tnum, ref op1, ref op2);
                Console.WriteLine("{0} {1} {2} {3} {4} ",fnum, op1, snum, op2, tnum);
                resbox.Text = calculate(fnum, snum, tnum, op1, op2).ToString();
            }

        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            Home f = new Home();
            f.Show();
            this.Close();
        }
    }
}
