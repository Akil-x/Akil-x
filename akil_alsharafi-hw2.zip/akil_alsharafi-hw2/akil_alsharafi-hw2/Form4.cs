﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace akil_alsharafi_hw2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private void numbox_event_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == '\b'))
            {
                e.Handled = true;
            }
        }
        private bool check_input()
        {
            if (fnumbox.Text == "")
            {
                MessageBox.Show("You Must Add The First Number");
                fnumbox.Focus();
            }
            else if (snumbox.Text == "")
            {
                MessageBox.Show("You Must Add The Secand Number");
                snumbox.Focus();
            }
            else
            {
                return true;
            }
            return false;
        }
        private void combolist_SelectedIndexChanged(object sender, EventArgs e)
        {
            double fnum = Convert.ToDouble(fnumbox.Text);
            double snum = Convert.ToDouble(snumbox.Text);
            double res = 0;

            if (check_input())
            {

                if (combolist.SelectedIndex != -1)
                {
                    if (combolist.SelectedItem.ToString() == "+")
                    {
                        res = fnum + snum;
                    }
                    else if (combolist.SelectedItem.ToString() == "-")
                    {
                        res = fnum - snum;

                    }

                    else if (combolist.SelectedItem.ToString() == "*")
                    {
                        res = fnum * snum;
                    }
                    else if (combolist.SelectedItem.ToString() == "/")
                    {
                        if (snum != 0)
                        {
                            res = fnum / snum;
                        }
                        else
                        {
                            MessageBox.Show("The Secand Number Can Not Be Zero .");
                            snumbox.Focus();
                            return;
                        }
                    }
                    resbox.Text = res.ToString();
                }
                else
                {
                    MessageBox.Show("You Have To Chose Opertion.");
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            fnumbox.Text = "";
            snumbox.Text = "";
            resbox.Text = "";
            //combolist.SelectedIndex = -1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Home f = new Home();
            f.Show();
            this.Close();
        }

    }
}
