﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace akil_alsharafi_hw2
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void vcm_Load(object sender, EventArgs e)
        {

        }

        private void p1btn_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void p2btn_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
            this.Hide();
        }

        private void p3btn_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3();
            f.Show();
            this.Hide();
        }

        private void p4btn_Click(object sender, EventArgs e)
        {
            Form4  f = new Form4();
            f.Show();
            this.Hide();

        }
    }
}
