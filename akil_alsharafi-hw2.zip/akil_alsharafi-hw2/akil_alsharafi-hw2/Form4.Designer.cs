﻿namespace akil_alsharafi_hw2
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.fnumbox = new System.Windows.Forms.TextBox();
            this.snumbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.resbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.combolist = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.calbtn = new System.Windows.Forms.Button();
            this.clearbtn = new System.Windows.Forms.Button();
            this.backbtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Number ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(224, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Opertion";
            // 
            // fnumbox
            // 
            this.fnumbox.Location = new System.Drawing.Point(36, 174);
            this.fnumbox.Name = "fnumbox";
            this.fnumbox.Size = new System.Drawing.Size(147, 32);
            this.fnumbox.TabIndex = 2;
            this.fnumbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.fnumbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.numbox_event_KeyPress);
            // 
            // snumbox
            // 
            this.snumbox.Location = new System.Drawing.Point(385, 174);
            this.snumbox.Name = "snumbox";
            this.snumbox.Size = new System.Drawing.Size(147, 32);
            this.snumbox.TabIndex = 4;
            this.snumbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.snumbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.numbox_event_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(381, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(171, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Second Number";
            // 
            // resbox
            // 
            this.resbox.Enabled = false;
            this.resbox.Location = new System.Drawing.Point(579, 174);
            this.resbox.Name = "resbox";
            this.resbox.Size = new System.Drawing.Size(147, 32);
            this.resbox.TabIndex = 6;
            this.resbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(623, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 24);
            this.label4.TabIndex = 5;
            this.label4.Text = "Result";
            // 
            // combolist
            // 
            this.combolist.FormattingEnabled = true;
            this.combolist.ItemHeight = 24;
            this.combolist.Items.AddRange(new object[] {
            "+",
            "-",
            "/",
            "*"});
            this.combolist.Location = new System.Drawing.Point(210, 155);
            this.combolist.Name = "combolist";
            this.combolist.Size = new System.Drawing.Size(159, 100);
            this.combolist.TabIndex = 7;
            this.combolist.SelectedIndexChanged += new System.EventHandler(this.combolist_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(268, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 34);
            this.label7.TabIndex = 9;
            this.label7.Text = "Third Form";
            // 
            // calbtn
            // 
            this.calbtn.Location = new System.Drawing.Point(36, 297);
            this.calbtn.Name = "calbtn";
            this.calbtn.Size = new System.Drawing.Size(147, 37);
            this.calbtn.TabIndex = 10;
            this.calbtn.Text = "Calucate";
            this.calbtn.UseVisualStyleBackColor = true;
            this.calbtn.Click += new System.EventHandler(this.combolist_SelectedIndexChanged);
            // 
            // clearbtn
            // 
            this.clearbtn.Location = new System.Drawing.Point(385, 297);
            this.clearbtn.Name = "clearbtn";
            this.clearbtn.Size = new System.Drawing.Size(147, 37);
            this.clearbtn.TabIndex = 11;
            this.clearbtn.Text = "Clear";
            this.clearbtn.UseVisualStyleBackColor = true;
            this.clearbtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // backbtn
            // 
            this.backbtn.Location = new System.Drawing.Point(579, 297);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(147, 37);
            this.backbtn.TabIndex = 12;
            this.backbtn.Text = "Back";
            this.backbtn.UseVisualStyleBackColor = true;
            this.backbtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label5.Location = new System.Drawing.Point(211, 310);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 24);
            this.label5.TabIndex = 13;
            this.label5.Text = "Akil Al-sharafi";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(781, 363);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.clearbtn);
            this.Controls.Add(this.calbtn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.combolist);
            this.Controls.Add(this.resbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.snumbox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.fnumbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.Name = "Form3";
            this.Text = "Akil-Alsharafi-HW2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox fnumbox;
        private System.Windows.Forms.TextBox snumbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox resbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox combolist;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button calbtn;
        private System.Windows.Forms.Button clearbtn;
        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.Label label5;
    }
}