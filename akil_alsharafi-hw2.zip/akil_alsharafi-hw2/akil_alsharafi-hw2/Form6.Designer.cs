﻿namespace akil_alsharafi_hw2
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.fnumbox = new System.Windows.Forms.TextBox();
            this.sumbtn = new System.Windows.Forms.Button();
            this.factbtn = new System.Windows.Forms.Button();
            this.rootbtn = new System.Windows.Forms.Button();
            this.Form5 = new System.Windows.Forms.Label();
            this.fact_label = new System.Windows.Forms.Label();
            this.root_label = new System.Windows.Forms.Label();
            this.backbtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(106, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(188, 34);
            this.label7.TabIndex = 10;
            this.label7.Text = "Fourth Form";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(114, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "Enater Number ";
            // 
            // fnumbox
            // 
            this.fnumbox.Location = new System.Drawing.Point(104, 132);
            this.fnumbox.Name = "fnumbox";
            this.fnumbox.Size = new System.Drawing.Size(179, 32);
            this.fnumbox.TabIndex = 12;
            this.fnumbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.fnumbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.numbox_event_KeyPress);
            // 
            // sumbtn
            // 
            this.sumbtn.Location = new System.Drawing.Point(22, 183);
            this.sumbtn.Name = "sumbtn";
            this.sumbtn.Size = new System.Drawing.Size(164, 42);
            this.sumbtn.TabIndex = 13;
            this.sumbtn.Text = "Sum";
            this.sumbtn.UseVisualStyleBackColor = true;
            this.sumbtn.Click += new System.EventHandler(this.sumbtn_Click);
            // 
            // factbtn
            // 
            this.factbtn.Location = new System.Drawing.Point(22, 242);
            this.factbtn.Name = "factbtn";
            this.factbtn.Size = new System.Drawing.Size(164, 42);
            this.factbtn.TabIndex = 14;
            this.factbtn.Text = "Fact";
            this.factbtn.UseVisualStyleBackColor = true;
            this.factbtn.Click += new System.EventHandler(this.factbtn_Click);
            // 
            // rootbtn
            // 
            this.rootbtn.Location = new System.Drawing.Point(22, 299);
            this.rootbtn.Name = "rootbtn";
            this.rootbtn.Size = new System.Drawing.Size(164, 42);
            this.rootbtn.TabIndex = 15;
            this.rootbtn.Text = "Root";
            this.rootbtn.UseVisualStyleBackColor = true;
            this.rootbtn.Click += new System.EventHandler(this.rootbtn_Click);
            // 
            // Form5
            // 
            this.Form5.AutoSize = true;
            this.Form5.Location = new System.Drawing.Point(287, 192);
            this.Form5.Name = "Form5";
            this.Form5.Size = new System.Drawing.Size(49, 24);
            this.Form5.TabIndex = 16;
            this.Form5.Text = "000";
            // 
            // fact_label
            // 
            this.fact_label.AutoSize = true;
            this.fact_label.Location = new System.Drawing.Point(287, 251);
            this.fact_label.Name = "fact_label";
            this.fact_label.Size = new System.Drawing.Size(49, 24);
            this.fact_label.TabIndex = 17;
            this.fact_label.Text = "000";
            // 
            // root_label
            // 
            this.root_label.AutoSize = true;
            this.root_label.Location = new System.Drawing.Point(287, 308);
            this.root_label.Name = "root_label";
            this.root_label.Size = new System.Drawing.Size(49, 24);
            this.root_label.TabIndex = 18;
            this.root_label.Text = "000";
            // 
            // backbtn
            // 
            this.backbtn.Location = new System.Drawing.Point(119, 352);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(164, 42);
            this.backbtn.TabIndex = 19;
            this.backbtn.Text = "Back";
            this.backbtn.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(133, 398);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 24);
            this.label2.TabIndex = 20;
            this.label2.Text = "Akil Al-sharafi";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(408, 431);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.root_label);
            this.Controls.Add(this.fact_label);
            this.Controls.Add(this.Form5);
            this.Controls.Add(this.rootbtn);
            this.Controls.Add(this.factbtn);
            this.Controls.Add(this.sumbtn);
            this.Controls.Add(this.fnumbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label7);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.Name = "Form4";
            this.Text = "Akil-Alsharafi-HW2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox fnumbox;
        private System.Windows.Forms.Button sumbtn;
        private System.Windows.Forms.Button factbtn;
        private System.Windows.Forms.Button rootbtn;
        private System.Windows.Forms.Label Form5;
        private System.Windows.Forms.Label fact_label;
        private System.Windows.Forms.Label root_label;
        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.Label label2;
    }
}